# read in the separate csv files of the Mazvidal and Till fight then the Diaz and Pettis fight
MaTi <- read.csv('MazvidalTillAlgorithmHitsBJJ.csv', header=TRUE, sep=',', na.strings=c('','NA'))
DiPe <- read.csv('DiazPettisAlgorithmHitsBJJ.csv', sep=',', header=TRUE, na.strings=c('','NA'))

# change the table colnames into M and D as X1 and T and P as X2
colnames(MaTi)[1:10] <- gsub('M','X1', colnames(MaTi)[1:10], ignore.case = FALSE, perl=TRUE)
colnames(MaTi)[7] <- 'cmTotHitsM.X1'
colnames(MaTi)[10] <- 'Hits.Mssd.X1'
colnames(MaTi)[11:16] <- gsub('T','X2', colnames(MaTi)[11:16], perl=TRUE, ignore.case=FALSE)
colnames(MaTi)[11:13] <- gsub('mX2','mT', colnames(MaTi)[11:13], ignore.case=FALSE)

colnames(DiPe)[4:9] <- gsub('D','X1', ignore.case = FALSE, colnames(DiPe)[4:9])
colnames(DiPe)[10:15] <- gsub('P','X2', ignore.case = FALSE, colnames(DiPe)[10:15])


# add in individual fight actions landed (stated in the notes)for each fighter
kicks_Mazvidal <- grep('^land.*kick.', MaTi$MasvidalFighterActionReactions)
kicks_Till <- grep('^land.*kick.', MaTi$TillFightersActionsReactions)
kicks_Diaz <- grep('^land.*kick.', DiPe$DiazFighterActionReactions)
kicks_Pettis <- grep('^land.*kick.', DiPe$PettisFightersActionsReactions)

elbows_Mazvidal <- grep('^land.*elbow.', MaTi$MasvidalFighterActionReactions)
elbows_Till <- grep('^land.*elbow.', MaTi$TillFightersActionsReactions)
elbows_Diaz <- grep('^land.*elbow.', DiPe$DiazFighterActionReactions)
elbows_Pettis <- grep('^land.*elbow.', DiPe$PettisFightersActionsReactions)

knees_Mazvidal <- grep('^land.*knee.', MaTi$MasvidalFighterActionReactions)
knees_Till <- grep('^land.*knee.', MaTi$TillFightersActionsReactions)
knees_Diaz <- grep('^land.*knee.', DiPe$DiazFighterActionReactions)
knees_Pettis <- grep('^land.*knee.', DiPe$PettisFightersActionsReactions)

jab_Mazvidal <- grep('^land.*jab.', MaTi$MasvidalFighterActionReactions)
jab_Till <- grep('^land.*jab.', MaTi$TillFightersActionsReactions)
jab_Diaz <- grep('^land.*jab.', DiPe$DiazFighterActionReactions)
jab_Pettis <- grep('^land.*jab.', DiPe$PettisFightersActionsReactions)

cross_Mazvidal <- grep('^land.*cross.', MaTi$MasvidalFighterActionReactions)
cross_Till <- grep('^land.*cross.', MaTi$TillFightersActionsReactions)
cross_Diaz <- grep('^land.*cross.', DiPe$DiazFighterActionReactions)
cross_Pettis <- grep('^land.*cross.', DiPe$PettisFightersActionsReactions)

hook_Mazvidal <- grep('^land.*hook.', MaTi$MasvidalFighterActionReactions)
hook_Till <- grep('^land.*hook.', MaTi$TillFightersActionsReactions)
hook_Diaz <- grep('^land.*hook.', DiPe$DiazFighterActionReactions)
hook_Pettis <- grep('^land.*hook.', DiPe$PettisFightersActionsReactions)

# remove the notes field
MaTi <- MaTi[,-19]
DiPe <- DiPe[,-19]

library(dplyr)

added <- mutate(MaTi, Cross.X1=0, Knee.X1=0, Elbow.X1=0, Hook.X1=0, Jab.X1=0, Kick.X1=0,
                Cross.X2=0, Knee.X2=0, Elbow.X2=0, Hook.X2=0, Jab.X2=0, Kick.X2=0)

added2 <- mutate(DiPe, Cross.X1=0, Knee.X1=0, Elbow.X1=0, Hook.X1=0, Jab.X1=0, Kick.X1=0,
                 Cross.X2=0, Knee.X2=0, Elbow.X2=0, Hook.X2=0, Jab.X2=0, Kick.X2=0)

# remove the instances with no action from either one
Added2 <- filter(added2, 
                 added2$DiazFighterActionReactions!=0 | added2$PettisFightersActionsReactions!=0)
Added <- filter(added, added$MasvidalFighterActionReactions !=0 | added$TillFightersActionsReactions !=0)


Added[cross_Mazvidal,'Cross.X1'] <- 1
Added[cross_Till,'Cross.X2'] <- 1
Added[hook_Mazvidal,'Hook.X1'] <- 1
Added[hook_Till,'Hook.X2'] <- 1
Added[jab_Mazvidal,'Jab.X1'] <- 1
Added[jab_Till,'Jab.X2'] <- 1
Added[knees_Mazvidal,'Knee.X1'] <- 1
Added[knees_Till,'Knee.X2'] <- 1
Added[elbows_Mazvidal,'Elbow.X1'] <- 1
Added[elbows_Till,'Elbow.X2'] <- 1
Added[kicks_Mazvidal,'Kick.X1'] <- 1
Added[kicks_Till,'Kick.X2'] <- 1

Added2[cross_Diaz,'Cross.X1'] <- 1
Added2[cross_Pettis,'Cross.X2'] <- 1
Added2[hook_Diaz,'Hook.X1'] <- 1
Added2[hook_Pettis,'Hook.X2'] <- 1
Added2[jab_Diaz,'Jab.X1'] <- 1
Added2[jab_Pettis,'Jab.X2'] <- 1
Added2[knees_Diaz,'Knee.X1'] <- 1
Added2[knees_Pettis,'Knee.X2'] <- 1
Added2[elbows_Diaz,'Elbow.X1'] <- 1
Added2[elbows_Pettis,'Elbow.X2'] <- 1
Added2[kicks_Diaz,'Kick.X1'] <- 1
Added2[kicks_Pettis,'Kick.X2'] <- 1

# Mazvidal and Diaz are X1 while Till and Pettis are X2
colnames(Added)[17] <- 'FighterActionReactions.X1'
colnames(Added)[18] <- 'FighterActionReactions.X2'
colnames(Added2)[17] <- 'FighterActionReactions.X1'
colnames(Added2)[18] <- 'FighterActionReactions.X2'

write.csv(Added, 'MazvidalTillUFC_addedFeatures.csv', row.names=F)
write.csv(Added2, 'DiazPettisUFC_addedFeatures.csv', row.names=F)

